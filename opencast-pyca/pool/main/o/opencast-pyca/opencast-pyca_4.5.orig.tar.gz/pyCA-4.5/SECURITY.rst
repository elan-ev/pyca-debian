Security Policy
===============

Supported Versions
------------------

We support only the latest version of this project.


Reporting a Vulnerability
-------------------------

If you find a security vulnerability,
please report it by sending a mail to security@lkiesow.de.
We will discuss the problem internally and, if necessary, release a patched version as soon as possible.
